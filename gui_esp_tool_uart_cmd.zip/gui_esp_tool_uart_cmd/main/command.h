/*
Written by Abhishek Tiwari
*/
#ifdef __cplusplus
extern "C" {
#endif

#ifndef COMMAND_H
#define COMMAND_H

//---libraries-----------------------
#include <stdio.h> //printf
#include <string.h>
#include "esp_log.h" //esplogi
#include "confg.h" //config.h for gpio call

static const char* TAG_COMMAND = "Command";
//-----commmands---------
/*
BT::TEST;
SETAK::12345678,12345678,12345678,12345678,12345678,12345678,12345678,12345678,12345678,12345678;
AK::12345678;
LOCK;
LOCKSTATUS;
LOCKFR;
RTC::DDMMYYHHMMSS;
IMEI?;
RTC?;
REBOOT;
COUNT;
KEY--;
VERSION;
OTA;
VTSCOMMOK;
IMEI::866557055739710;
*/
#define command1 (char*)"BT::TEST;"
#define command2 (char*)"SETAK::12345678,12345678,12345678,12345678,12345678,12345678,12345678,12345678,12345678,12345678;"
#define command3 (char*)"AK::12345678;"
#define command4 (char*)"LOCK;"
#define command5 (char*)"LOCKSTATUS;"
#define command6 (char*)"LOCKFR;"
#define command7 (char*)"RTC::DDMMYYHHMMSS;"
#define command8 (char*)"IMEI?;"
#define command9 (char*)"RTC?;"
#define command10 (char*)"REBOOT;"
#define command11 (char*)"COUNT;"
#define command12 (char*)"KEY--;"
#define command13 (char*)"VERSION;"
#define command14 (char*)"OTA;"
#define command15 (char*)"VTSCOMMOK;"
#define command16 (char*)"IMEI::123456789123456;"
//////////////////////////////////////////////////
//------response list-------------------------
/*
$RES,BT SETTEST;
$RES,MASTER KEY SET;
$RES,UNLOCKING...;
$RES,UNLOCKED=46;
$RES,LOCKING...;
$RES,LOCKED=COUNT;
$RES,IMEI:866557055739710
RTC:03:09:22,08:41:16                                                            
TS:1                                                                                
LS:1                                                                                 
BT:TL-2a:1f:21:a4                                                       
UC:0
VER:
$RES,VER:ATL_AUTO_LOCK_2.0_OTA_1.0s;
$RES,FACTORY RESET DONE;
$RES,RTC SET;
$RES,IMEI::866557055739710;
$RES,RTC::03:09:22,09:13:43;
$RES,LOCK,REBOOT;
$RES,Count=20;
$RES,KEY REMOVED;
$RES,$RES,VER:ATL_AUTO_LOCK_2.0_OTA_1.0s;
$RES,VTS COMM OK…;
//OTA
$RES,IMEI SET::866557055739710;
*/


#define response1 (char*)"$RES,BT SETTEST;"
#define response2 (char*)"$RES,MASTER KEY SET;"
#define response3 (char*)"$RES,UNLOCKING...;$RES,UNLOCKED=46;"
#define response4 (char*)"$RES,LOCKING...;$RES,LOCKED=COUNT;"
#define response5 (char*)"$RES,IMEI:866557055739710\nRTC:03:09:22,08:41:16\nTS:1\nLS:1\nBT:TL-2a:1f:21:a4\nUC:0\nVER:$RES,VER:ATL_AUTO_LOCK_2.0_OTA_1.0s;"
#define response6 (char*)"$RES,FACTORY RESET DONE;"
#define response7 (char*)"$$RES,RTC SET;"
#define response8 (char*)"$RES,IMEI::866557055739710;"
#define response9 (char*)"$RES,RTC::03:09:22,09:13:43;"
#define response10 (char*)"$RES,LOCK,REBOOT;"
#define response11 (char*)"$RES,Count=20;"
#define response12 (char*)"$RES,KEY REMOVED;"
#define response13 (char*)"$RES,$RES,VER:ATL_AUTO_LOCK_2.0_OTA_1.0s;"
#define response14 (char*)"$RES,PENDING;"
#define response15 (char*)"$RES,VTS COMM OK…;"
#define response16 (char*)"$RES,IMEI SET::866557055739710;"
#define responseError (char*)"Error Response"
//////////////////////////////////////////////
//--------funtions---------
void responseSend(char* _command);
char* commandList (char comman_Num);
void command_Process (char* input);
void initListen();
#endif
#ifdef __cplusplus
}
#endif// COMMAND_H 