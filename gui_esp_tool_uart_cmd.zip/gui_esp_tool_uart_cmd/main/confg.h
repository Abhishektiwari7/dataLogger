/*
Written by Abhishek Tiwari
*/
#ifdef __cplusplus
extern "C" {
#endif

#ifndef CONFG_H
#define CONFG_H

//---libraries-----------------------
#include <stdio.h> //printf
#include "freertos/FreeRTOS.h" //taskcreate
#include "freertos/task.h" //taskdelay

#include "driver/uart.h" //uart gpio
#include "driver/gpio.h" //led gpio

#include "esp_log.h" //esplogi

//select which uart you wan to run command?
#if 1 //1 for uart 1 //0 for uart 0
//---uart-1 ---for ttl and command----
#define TXD (4)
#define RXD (5)
#define RTS (0)
#define CTS (0)
#define UART_PORT_NUM      (1)
#else
//------UART-0---same as esplogi default--
#define TXD (1)
#define RXD (3)
#define RTS (0)
#define CTS (0)
#define UART_PORT_NUM      (0)
#endif

#define UART_BAUD_RATE     (115200)
#define TASK_STACK_SIZE    (1024*2)

#define BUF_SIZE (1024)
static const char* TAG_CONFIG = "Configuration";
//------LED------
#define LED0 2 //active high 
#define LED1 4 //active high
//--------funtions---------
void initConfg();

#endif
#ifdef __cplusplus
}
#endif// CONFG_H 