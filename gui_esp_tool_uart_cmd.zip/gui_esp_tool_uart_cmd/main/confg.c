#include "confg.h"

void initConfg() {
/* Configure parameters of an UART driver,
* communication pins and install the driver */
uart_config_t uart_config = {
.baud_rate = UART_BAUD_RATE,
.data_bits = UART_DATA_8_BITS,
.parity    = UART_PARITY_DISABLE,
.stop_bits = UART_STOP_BITS_1,
.flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
.source_clk = UART_SCLK_DEFAULT,
};

int intr_alloc_flags = 0;
#if CONFIG_UART_ISR_IN_IRAM
intr_alloc_flags = ESP_INTR_FLAG_IRAM;
#endif

ESP_ERROR_CHECK(uart_driver_install(UART_PORT_NUM, BUF_SIZE * 2, 0, 0, NULL, intr_alloc_flags));
ESP_ERROR_CHECK(uart_param_config(UART_PORT_NUM, &uart_config));
ESP_ERROR_CHECK(uart_set_pin(UART_PORT_NUM, TXD, RXD, RTS, CTS));

ESP_LOGI(TAG_CONFIG, "Init UART->>%d",UART_PORT_NUM);
ESP_LOGI(TAG_CONFIG, "TX->>%d, RX->>%d, Baudrate->>%d",TXD,RXD,UART_BAUD_RATE);
ESP_LOGI(TAG_CONFIG, "Init LED0->>%d,LED1->>%d",LED0,LED1);
gpio_reset_pin(LED0);
gpio_reset_pin(LED1);
gpio_set_direction(LED0,GPIO_MODE_OUTPUT);
gpio_set_direction(LED1,GPIO_MODE_OUTPUT);

ESP_LOGI(TAG_CONFIG, "Config Done");
}