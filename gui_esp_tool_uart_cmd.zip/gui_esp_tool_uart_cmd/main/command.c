#include "command.h"

//--------Listen uart data from serial-------------------------
static void listen_task(void *arg) {
uint8_t *data_ = (uint8_t *) malloc(BUF_SIZE);
while (1) {
int len = uart_read_bytes(UART_PORT_NUM, data_, (BUF_SIZE - 1), 20 / portTICK_PERIOD_MS); //Read data from the UART 
if (len) { // if there is data then call command proccess function
    gpio_set_level(LED0, 1);
    gpio_set_level(LED1, 1);
    // data_[len] = '\n'; //old method for python need some advise here
    // data_[len+1] = '\0';
    data_[len] = '\0';
    ESP_LOGI(TAG_COMMAND, "\nUart Listen Recv data->>%s,Length->>%d\n", (char *) data_,len);
    command_Process ((char *)data_);
    gpio_set_level(LED0, 0);
    gpio_set_level(LED1, 0);
}//end of if data?
}//end of while
}//end of task
////////////////////////////////////////////////////////////////

///-----------init task-------------------------------------
void initListen() {
xTaskCreate(listen_task, "listen_task", 1024*2, NULL, 10, NULL);
}
//////////////////////////////////////////////////////////////

//----------Send response to Uart Tx to Gui--------------------
void responseSend(char* _command) {
//char *data = (char *) malloc(BUF_SIZE);
int len = strlen(_command);
gpio_set_level(LED0, 1);
gpio_set_level(LED1, 1);

uart_write_bytes(UART_PORT_NUM, _command, len);

gpio_set_level(LED0, 0);
gpio_set_level(LED1, 0);

}
////////////////////////////////////////////
//-------list of command for debug testing-------------------------
char* commandList (char comman_Num) {
    switch (comman_Num) {
        case 1:
        return command1;
        case 2:
        return command2;
        case 3:
        return command3;
        case 4:
        return command4;
        case 5:
        return command5;
        case 6:
        return command6;
        case 7:
        return command7;
        case 8:
        return command8;
        case 9:
        return command9;
        case 10:
        return command10;
        case 11:
        return command11;
        case 12:
        return command12;
        case 13:
        return command13;
        case 14:
        return command14;
        case 15:
        return command15;
        case 16:
        return command16;
        
        default:
        return 0;
    }
}
///////////////////////////////////////////////////////////////////
//-------------incoming commands are proccess here and response send to gui------------------
void command_Process (char* input) {
ESP_LOGI(TAG_COMMAND, "..Command Process Function Call..");
if (strcmp(command1, input) == 0) { //true
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response1);
} else if (strcmp(command2, input) == 0) {
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response2);
}else if (strcmp(command3, input) == 0) {
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response3);
}else if (strcmp(command4, input) == 0) {
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response4);
}else if (strcmp(command5, input) == 0) {
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response5);
}else if (strcmp(command6, input) == 0) {
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response6);
}else if (strcmp(command7, input) == 0) {
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response7);
}else if (strcmp(command8, input) == 0) {
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response8);
}else if (strcmp(command9, input) == 0) {
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response9);
}else if (strcmp(command10, input) == 0) {
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response10);
}else if (strcmp(command11, input) == 0) {
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response11);
}else if (strcmp(command12, input) == 0) {
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response12);
}else if (strcmp(command13, input) == 0) {
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response13);
}else if (strcmp(command14, input) == 0) {
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response14);
}else if (strcmp(command15, input) == 0) {
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response15);
}else if (strcmp(command16, input) == 0) {
    ESP_LOGI(TAG_COMMAND, "Command->>%s",input);
    responseSend (response16);
} else {
    ESP_LOGI(TAG_COMMAND, " This->>%s->>Not Available Command, Add new and check",input);
    responseSend (responseError);
    responseSend (input);    
}
} //command process