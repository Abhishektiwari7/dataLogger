//Written by Abhishek Tiwari
#include "confg.h" //init uart and led gpio
#include "command.h" //Command process

static const char* TAG_MAIN = "Main";

void app_main(void) {
initConfg(); //uart and gpio
initListen(); //create listener task

// for (uint8_t i=1; i<17;i++) { //test command pallete only to debug purpose
//     command_Process (commandList (i)); //proccess command
// }
while (1) {
    vTaskDelay(100 / portTICK_PERIOD_MS); //freertos to feed watchdog
}//end of while loop
}//end of Appmain